export class Token {
    public userId:number;
    public username:string;
    public tokens:string;
    public message:string;
}
